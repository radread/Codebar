/* Exercise 1: Wish list */
